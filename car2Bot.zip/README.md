# Telegram Montenegro Car Price Bot

Автоматически парсит объявления по цене, проверяет раз в 5 минут и публикует новые в Telegram (≤ заданной цене).

## Установка

```bash
pip install -r requirements.txt

